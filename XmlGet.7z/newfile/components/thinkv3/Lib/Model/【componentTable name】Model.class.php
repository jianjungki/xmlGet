<?php
    /**
     * GiftModel
     * 礼物数据模型
     *
     * @uses 
     * @package 
     * @version 
     * @copyright 2009-2011 SamPeng 水上铁
     * @author SamPeng <sampeng87@gmail.com> 水上铁<wxm201411@163.com> 
     * @license PHP Version 5.2 {@link www.sampeng.cn}
     */
	class GiftModel extends Model{
		/**
		 * _initialize
		 * 初始化函数
		 * @return void
		 */
		public function _initialize(){
            parent::_initialize();
		}
	
	}
?>