<?php
/*$info = "【$V3UNDER JGLabel 9ee21c838fa542e6acb7e51f1c18acc0】start    【$V3UNDER JGLabel 9ee21c838fa542e6acb7e51f1c18acc0】end";
 $value = preg_replace("|【$V3UNDER.?JGLabel.?9ee21c838fa542e6acb7e51f1c18acc0】.?start[\S\s]*【$V3UNDER.?JGLabel.?9ee21c838fa542e6acb7e51f1c18acc0】.?end|", "val = '【propertys.Height/100】';", $info);
 var_dump($value);*/
 /*
 @param xml文件地址
 @param 生成的文件的存放地址
 @return 返回结果:1为成功，0为出现异常中断
 */
include_once('tbszip.php'); // load the TbsZip library

 $package_file = "new/package.zip";
 $execute_file = "new/package.xml";
if(file_exists($execute_file)){
    $content = file_get_contents($execute_file);
}else{
	$zip = new clsTbsZip(); // create a new instance of the TbsZip class
    $zip->Open($package_file); // open an existing archive for reading and/or modifying
	$content = $zip->FileRead("package.xml");
}

$get = new XMLCrash($content);




class XMLCrash{
private $source_file;
private $arg = array();//单属性解析
private $set = array();
private $forit = array();//复合标签解析
private $index = array();
private $tmpfile;
private $filenow;
private $pinfo;
function __construct($content){
	
	$xml = simplexml_load_string($content,'SimpleXMLElement',LIBXML_NOCDATA);
	
	if($xml){
		$configfile = array(
			"Common",
			"AppInfo",
			"Lib",
			"Language",
			"Cof"
		);

		foreach ($xml->components->component as $key => $value) {
			$ruleInstances = $value->ruleInstances;//组件属性
		    //$filenow = "V3/Tpl/default/";
		    $filenow = "new/model";
		    $fileout = "apps";
		    $property = $value->propertys;//组件属性
		    $control = $value->controls;//组件，需要遍历
		    $getid = $value->attributes()->id;
		    $act = $value->componentVariants->xPath("componentVariant[@name='act']");
		    $app = $value->componentVariants->xPath("componentVariant[@name='app']");
		    $mod = $value->componentVariants->xPath("componentVariant[@name='mod']");
		    $fileout = $fileout."/".$app[0]->attributes()->initValue."/Tpl/default/".$mod[0]->attributes()->initValue."/".$act[0]->attributes()->initValue;

		    if(is_dir($filenow.$value->attributes()->id)){
		    	$filenow = $filenow.$value->attributes()->id;
		    }else if(is_dir($filenow."tenc")){
		    	$filenow = $filenow."tenc";
		    }else if(is_dir($filenow."v3")){
		    	$filenow = $filenow."v3";
		    }
			$this->filename = $filenow."/index.html";
			if(!file_exists($this->filename)){
				echo $this->filename."不存在";
				return 0;
			}
			$this->tmpfile =  file_get_contents($this->filename);
		    $this->fileinfo = $this->parse($this->arg,$this->set,$this->tmpfile);
		    $this->xml2control($control,$filenow);
		    $fp=fopen($fileout.".html","a+");//fopen(),读操作
			if(!(preg_match("|.?haveedit.*|",fgets($fp,20)))){
				fclose($fp);
				unlink($fileout.".html");
				$fp=fopen($fileout.".html","w");//fopen(),写操作
				fputs($fp,$this->fileinfo);
			}

			fclose($fp);
			echo $filenow."生成成功<br>";
			
		}
		return 1;
	}
}


function arr_foreach($name="",$arr){//json解析函数
	if(!is_array ($arr)){//递归出口
		return false;
	}
	foreach ($arr as $key => $val ) { //递归解析数组

		if (is_array ($val)&&!is_numeric($key)) {
			if(empty($name)){
				$name = $key; 
			}else{
				$name = $name . "." .$key;
			}
			$this->arr_foreach ($name,$val); 
		}else if(!is_array ($val)){//解析不是数组的内容，元素
			$this->forit[] = "propertys.".$name.".".$key;
			$this->index[] = $val;
		}else if(is_array ($val)&&is_numeric($key)){//解析既是数组又是数字的内容
			$this->forit[] = "propertys.".$name;
			$this->index[] = $arr;
			break;//如果是数字下标，则直接飘过，只需要上一个名字
		}
		
		//echo $val."<br>"; 
	}

    if(!empty($this->index)){ //索引序列
    	foreach ($this->index as $key => $value) {
	    	$this->set[] = $value;	
    	}
    	foreach ($this->forit as $key => $value) {
    		$this->arg[] = $value;
    	}

    }
    unset($this->forit);
	unset($this->index);

	return;
	
}


function xml2control($xml,$filenow){//递归解析xml数据

	if($xml->attributes()){//判断解析目录，并且把标签属性加入待解析内容
		$mainpath = "new/model/control/".$xml->attributes()->type."/".$xml->attributes()->id."/index.html";
		$nextpath = "new/model/control/".$xml->attributes()->type."/index.html";
		if(!file_exists($mainpath)&&!file_exists($nextpath)){
			return;
		}else if(!file_exists($mainpath)&&file_exists($nextpath)){
			$this->filename = $nextpath;
			$filenow = "new/model/control/".$xml->attributes()->type;
		}else if(file_exists($mainpath)){
			$this->filename = $mainpath;
			$filenow = "new/model/control/".$xml->attributes()->type."/".$xml->attributes()->id;
		}

		foreach ($xml->attributes() as $key => $value) {
			$this->arg[] =  $key;
			$this->set[] =  $value;
		}
	}
	if($xml->propertys){//配置内容添加入解析队列
		foreach ($xml->propertys->property as $key=>$value) {
			//非json转化的普通数据
			    if($value->attributes()->name=="Visible"&&$value=="False"){
			    	 $this->fileinfo = $this->file_combine($xml->attributes(),"",$this->fileinfo);
			    	 unset($this->arg);unset($this->set);return;
			    }
				$this->arg[] =  "propertys.".$value->attributes()->name;
				$this->set[] =  $value;
		}
		
		$this->tmpfile = file_get_contents($this->filename);
		$content = $this->parse($this->arg,$this->set,$this->tmpfile);
		$this->fileinfo = $this->file_combine($xml->attributes(),$content,$this->fileinfo);
	}
	
	if(count($xml->controls)||count($xml->control)){
		if(count($xml->controls)){
			$this->xml2control($xml->controls,$filenow);
		}else{
			for ($i=count($xml->control)-1; $i >= 0 ; $i--) {
				$this->xml2control($xml->control[$i],$filenow);
			}
		}
	}
}
//合并文件，按照解析规则
function file_combine($xmlib,$vals,$content){
	if(empty($content)){
		return $vals;
	}else{
		$info = preg_replace("|【$V3UNDER.+".$xmlib->type.".+".$xmlib->id."】.?start[\s\S][^\【]*【$V3UNDER.+".$xmlib->type.".+".$xmlib->id."】.?end|",$vals,$content);
		return $info;
	}
}

function parse($tags,$vals,$file_content){ //标签内容映射
          if(!is_array($tags)){ 
             $value = preg_replace("|【".$tags."】|",$vals,$file_content);  
          }else{ 
             $an = count($tags); 
             for($i=0;$i<$an;$i++){ 
                $tags[$i] = "|【".$tags[$i]."】|"; 
             } 
            $value = preg_replace($tags,$vals,$file_content);  

         }
          unset($this->arg);unset($this->set); 
          return $value;
   }
}
?>